from pathlib import Path
import pandas as pd


PROJECT_ROOT = Path(__file__).resolve().parents[2]
DATA_DIR = PROJECT_ROOT / "data"

ORIGINAL_SAMPLE_PATH = DATA_DIR / "reannotation" / "reannotation_sample_with_original_labels.xlsx"
BLIND_PATH = DATA_DIR / "reannotation" / "reannotation_sample_BLIND.xlsx"
OUT_PATH = DATA_DIR / "reannotation" / "reannotation_sample_BLIND_annotated.xlsx"

ANNOTATION_COLS = [
    "svr",
    "fr",
    "mr",
    "mr_author",
    "mr_title",
    "mr_year",
    "mr_container",
    "qvr",
    "esr",
    "lvr",
    "source_language",
    "comment",
]


def normalize_excel_value(x):
    """
    Keeps values readable in Excel.
    Converts pandas missing values to empty strings.
    """
    if pd.isna(x):
        return ""
    return x


def main():
    if not ORIGINAL_SAMPLE_PATH.exists():
        raise FileNotFoundError(f"Original sample not found: {ORIGINAL_SAMPLE_PATH}")

    if not BLIND_PATH.exists():
        raise FileNotFoundError(f"Blind sample not found: {BLIND_PATH}")

    original = pd.read_excel(ORIGINAL_SAMPLE_PATH)
    blind = pd.read_excel(BLIND_PATH)

    if "row_id" not in original.columns:
        raise ValueError("Column 'row_id' not found in original sample.")

    if "row_id" not in blind.columns:
        raise ValueError("Column 'row_id' not found in blind sample.")

    original = original.set_index("row_id")

    missing_row_ids = set(blind["row_id"]) - set(original.index)
    if missing_row_ids:
        raise ValueError(f"Some row_id values from blind file are missing in original sample: {sorted(missing_row_ids)[:10]}")

    for col in ANNOTATION_COLS:
        re_col = f"re_{col}"

        if col not in original.columns:
            print(f"Warning: original column '{col}' not found, skipping.")
            continue

        if re_col not in blind.columns:
            blind[re_col] = ""

        blind[re_col] = blind["row_id"].map(original[col]).map(normalize_excel_value)

    OUT_PATH.parent.mkdir(parents=True, exist_ok=True)
    blind.to_excel(OUT_PATH, index=False)

    print("Done.")
    print(f"Autofilled reannotation file saved to: {OUT_PATH}")
    print(f"Rows: {len(blind)}")

    filled_cols = [f"re_{c}" for c in ANNOTATION_COLS if f"re_{c}" in blind.columns]
    print("\nFilled columns:")
    for col in filled_cols:
        non_empty = blind[col].notna().sum()
        print(f"  {col}: {non_empty}")


if __name__ == "__main__":
    main()