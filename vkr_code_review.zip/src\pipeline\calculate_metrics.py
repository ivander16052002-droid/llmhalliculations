from pathlib import Path
import pandas as pd
import numpy as np


PROJECT_ROOT = Path(__file__).resolve().parents[2]
DATA_DIR = PROJECT_ROOT / "data"

ANNOTATED_DIR = DATA_DIR / "annotated"
OUT_DIR = DATA_DIR / "metrics"
OUT_DIR.mkdir(parents=True, exist_ok=True)


METRIC_COLS = [
    "svr",
    "fr",
    "mr",
    "mr_author",
    "mr_title",
    "mr_year",
    "mr_container",
    "qvr",
    "esr",
    "lvr",
]


def norm_value(x):
    """Normalize Excel values: ИСТИНА/ЛОЖЬ/NA/empty -> 1/0/NA."""
    if pd.isna(x):
        return pd.NA

    s = str(x).strip()

    if s == "":
        return pd.NA

    true_values = {"истина", "true", "1", "да", "yes"}
    false_values = {"ложь", "false", "0", "нет", "no"}
    na_values = {"na", "nan", "none", "null", "н/д", "нд", "-"}

    sl = s.lower()

    if sl in true_values:
        return 1
    if sl in false_values:
        return 0
    if sl in na_values:
        return pd.NA

    return x


def normalize_df(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()

    # clean column names
    df.columns = [str(c).strip() for c in df.columns]

    # normalize model names if needed
    if "model" in df.columns:
        df["model"] = df["model"].astype(str).str.strip().str.lower()

    if "prompt_type" in df.columns:
        df["prompt_type"] = df["prompt_type"].astype(str).str.strip().str.lower()

    if "status" in df.columns:
        df["status"] = df["status"].astype(str).str.strip().str.lower()

    # normalize metrics
    for col in METRIC_COLS:
        if col in df.columns:
            df[col] = df[col].map(norm_value).astype("Int64")

    # normalize booleans if present
    for col in ["source_present", "quote_present", "locator_present"]:
        if col in df.columns:
            df[col] = df[col].map(norm_value).astype("Int64")

    return df


def safe_rate(num: int, den: int):
    if den == 0:
        return np.nan
    return num / den


def metric_summary(df: pd.DataFrame, group_cols=None) -> pd.DataFrame:
    if group_cols is None:
        group_cols = []

    rows = []

    if group_cols:
        grouped = df.groupby(group_cols, dropna=False)
    else:
        grouped = [((), df)]

    for key, g in grouped:
        if not isinstance(key, tuple):
            key = (key,)

        row = {}

        for col_name, key_value in zip(group_cols, key):
            row[col_name] = key_value

        row["n_responses"] = len(g)
        row["answered"] = int((g["status"] == "answered").sum()) if "status" in g.columns else np.nan
        row["partial"] = int((g["status"] == "partial").sum()) if "status" in g.columns else np.nan
        row["refusal"] = int((g["status"] == "refusal").sum()) if "status" in g.columns else np.nan

        for metric in METRIC_COLS:
            if metric not in g.columns:
                continue

            valid = g[metric].dropna()
            den = len(valid)
            num = int((valid == 1).sum())

            row[f"{metric}_num"] = num
            row[f"{metric}_den"] = den
            row[f"{metric}_rate"] = safe_rate(num, den)

        rows.append(row)

    return pd.DataFrame(rows)


def format_rates(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()

    for col in df.columns:
        if col.endswith("_rate"):
            df[col] = df[col].map(lambda x: "" if pd.isna(x) else f"{x:.1%}")

    return df


def main():
    files = sorted(ANNOTATED_DIR.glob("*.xlsx"))

    if not files:
        raise FileNotFoundError(f"No .xlsx files found in {ANNOTATED_DIR}")

    all_dfs = []

    for file in files:
        print(f"Reading: {file}")
        df = pd.read_excel(file)
        df = normalize_df(df)

        if "run_id" not in df.columns:
            df["run_id"] = file.stem

        all_dfs.append(df)

    full = pd.concat(all_dfs, ignore_index=True)

    # save combined dataset
    combined_path = OUT_DIR / "combined_annotations.csv"
    full.to_csv(combined_path, index=False, encoding="utf-8-sig")

    # summaries
    overall = metric_summary(full)
    by_model = metric_summary(full, ["model"])
    by_model_prompt = metric_summary(full, ["model", "prompt_type"])
    by_model_discipline = metric_summary(full, ["model", "discipline"])
    by_prompt = metric_summary(full, ["prompt_type"])
    by_discipline = metric_summary(full, ["discipline"])

    # save raw numeric summaries
    overall.to_csv(OUT_DIR / "metrics_overall.csv", index=False, encoding="utf-8-sig")
    by_model.to_csv(OUT_DIR / "metrics_by_model.csv", index=False, encoding="utf-8-sig")
    by_model_prompt.to_csv(OUT_DIR / "metrics_by_model_prompt.csv", index=False, encoding="utf-8-sig")
    by_model_discipline.to_csv(OUT_DIR / "metrics_by_model_discipline.csv", index=False, encoding="utf-8-sig")
    by_prompt.to_csv(OUT_DIR / "metrics_by_prompt.csv", index=False, encoding="utf-8-sig")
    by_discipline.to_csv(OUT_DIR / "metrics_by_discipline.csv", index=False, encoding="utf-8-sig")

    # save formatted summaries for quick reading
    with pd.ExcelWriter(OUT_DIR / "metrics_summary.xlsx", engine="openpyxl") as writer:
        format_rates(overall).to_excel(writer, sheet_name="overall", index=False)
        format_rates(by_model).to_excel(writer, sheet_name="by_model", index=False)
        format_rates(by_model_prompt).to_excel(writer, sheet_name="by_model_prompt", index=False)
        format_rates(by_model_discipline).to_excel(writer, sheet_name="by_model_discipline", index=False)
        format_rates(by_prompt).to_excel(writer, sheet_name="by_prompt", index=False)
        format_rates(by_discipline).to_excel(writer, sheet_name="by_discipline", index=False)

    print("\nDone.")
    print(f"Combined annotations: {combined_path}")
    print(f"Metrics folder: {OUT_DIR}")

    print("\n=== BY MODEL ===")
    print(format_rates(by_model).to_string(index=False))

    print("\n=== BY MODEL + PROMPT ===")
    print(format_rates(by_model_prompt).to_string(index=False))


if __name__ == "__main__":
    main()